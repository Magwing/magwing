﻿#include <iostream>
#include <thread>
#include <fstream>
#include "direct.h"
#include <string>
#include <map>
using namespace std;
//bot文本资源环境的输入 预先定义为undefined 以设置为未输入的状态
string text="/*undefined*/";
//文本是否被改变了 以便提示子线程是否需要处理新信息
bool textChange = false;
int TrueOrFalse(int x)
{
    bool a = (x ? "True" : "False");
    return a;
}
void stm() 
{
}
void input() {
    while (1) {
        if (textChange == true) {
            if (TrueOrFalse(text == "t")==true) {
                cout << "sd";
            }
            else {
                if (text == "talker sign up") {
                    cout << "sdd";
                }
                else {
                    cout << "std";
                }
            }
            textChange = false;
        }
    }
}
void VisualStatus() {

}
void environment() {

}
int fileCreating() {
    _mkdir("./brain");
    _mkdir("./brain/memory");
    _mkdir("./Environ");
    _mkdir("./TalkerVertify");
    char* path = "./brain/memory/text.mem";
    ofstream fout(path);
    return 0;
}
int newThreads() {
    thread Stm(stm);
    Stm.detach();
    thread Input(input);
    Input.detach();
    return 0;
}
int main()
{
    fileCreating();
    newThreads();
    while (1) {
        getline(cin, text);
        //检测用户是否输入了
        if (text!= "/*undefined*/") {
            cout << "<!--log: The main thread got new input-->" << endl;
            textChange = true;
        }
        text = "/*undefined*/";
    }
}

